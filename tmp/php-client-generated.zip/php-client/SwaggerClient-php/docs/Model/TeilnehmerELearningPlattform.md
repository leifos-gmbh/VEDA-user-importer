# TeilnehmerELearningPlattform

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**benutzername** | **string** | Der Benutzername für die E-Learning-Plattform | [optional] 
**elearning_plattform_id** | **string** |  | [optional] 
**email** | **string** |  | [optional] 
**initiales_passwort** | **string** | Das initiale Passwort für die E-Learning-Plattform | [optional] 
**links** | [**\Swagger\Client\Model\Link[]**](Link.md) |  | [optional] 
**teilnehmer** | [**\Swagger\Client\Model\Teilnehmer**](Teilnehmer.md) | Teilnehmer der E-Learning-Plattform | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


