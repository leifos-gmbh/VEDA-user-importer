# Veranstaltungsort

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hausnr** | **string** | Hausnummer der Anschrift des Veranstaltungsorts | [optional] 
**homepage** | **string** | Homepage des Veranstaltungsorts | [optional] 
**name** | **string** | Name des Veranstaltungsorts | [optional] 
**ort** | **string** | Ort der Anschrift des Veranstaltungsorts | [optional] 
**plz** | **string** | PLZ der Anschrift des Veranstaltungsorts | [optional] 
**strasse** | **string** | Straße der Anschrift des Veranstaltungsorts | [optional] 
**telefon1** | **string** | Telefonnummer des Veranstaltungsorts | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


