# Veranstaltungskategorie

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bezeichnung** | **string** | Bezeichnung der Veranstaltungskategorie | [optional] 
**links** | [**\Swagger\Client\Model\Link[]**](Link.md) |  | [optional] 
**oid** | **string** | Eindeutige ID der Veranstaltungskategorie | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


