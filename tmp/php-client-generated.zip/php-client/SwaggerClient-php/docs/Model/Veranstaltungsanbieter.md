# Veranstaltungsanbieter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**admin_e_mail** | **string** | Administrative E-Mail-Adresse des Veranstaltungsanbieters | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


