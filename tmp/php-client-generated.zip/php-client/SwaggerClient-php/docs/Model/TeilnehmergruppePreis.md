# TeilnehmergruppePreis

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**preis** | **float** | Der Preis für den Veranstaltungstermin. | [optional] 
**teilnehmergruppe_id** | **string** | Die ID der Teilnehmergruppe, für die der Preis angegeben ist. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


