# LernerfolgMeldenApiDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lernerfolg** | **bool** | Angabe des Lernerfolgs. Default ist &#39;false&#39;. | [optional] 
**lernerfolg_gemeldet_am** | [**\DateTime**](\DateTime.md) | Optionale Angabe, wann der Lernerfolg gemeldet wurde. Default ist &#39;Heute&#39;. | [optional] 
**links** | [**\Swagger\Client\Model\Link[]**](Link.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


