# Ausbildungsgangabschnitt

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**oid** | **string** | UUID des Datensatzes | 
**ausbildungsgangabschnittsart** | **string** | Art des Ausbildungsgangabschnitts | 
**bezeichnung** | **string** | Bezeichnung des Ausbildungsgangabschnitt | 
**kurz_bezeichnung** | **string** | Kurzbezeichnung des Ausbildungsgangabschnitt | 
**links** | [**\Swagger\Client\Model\Link[]**](Link.md) |  | [optional] 
**reihenfolge** | **int** | Nummer zur Bestimmung der Reihenfolge | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


