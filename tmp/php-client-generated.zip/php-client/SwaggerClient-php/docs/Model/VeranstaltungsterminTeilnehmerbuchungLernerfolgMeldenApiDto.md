# VeranstaltungsterminTeilnehmerbuchungLernerfolgMeldenApiDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**\Swagger\Client\Model\Link[]**](Link.md) |  | [optional] 
**teilnahme_erfolgreich** | **bool** | TeilnahmeErfolgreich dokumentiert, ob die Teilnahme erfolgreich (true) oder nicht erfolgreich (false) war. Der Default ist false. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


