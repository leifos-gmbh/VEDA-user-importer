# Ausbildungsgang

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**oid** | **string** | UUID des Datensatzes | 
**ausbildungsgangabschnitte** | [**\Swagger\Client\Model\Ausbildungsgangabschnitt[]**](Ausbildungsgangabschnitt.md) | Liste der Ausbildungsgangabschnitte | 
**bezeichnung** | **string** | Bezeichnung des Ausbildungsgangs | 
**kurzbezeichnung** | **string** | Kurzbezeichnung des Ausbildungsgangs | 
**links** | [**\Swagger\Client\Model\Link[]**](Link.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


