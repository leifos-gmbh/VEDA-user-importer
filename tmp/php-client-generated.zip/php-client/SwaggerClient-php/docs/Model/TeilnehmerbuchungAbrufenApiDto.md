# TeilnehmerbuchungAbrufenApiDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**oid** | **string** | UUID des Datensatzes | 
**links** | [**\Swagger\Client\Model\Link[]**](Link.md) |  | [optional] 
**teilnehmer_id** | **string** | ID des Teilnehmers der auf das Web Based Training gebucht werden soll. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


